package com.java.crimemanagement.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.crimemanagement.model.Crime;
import com.java.crimemanagement.util.DBConnUtil;
import com.java.crimemanagement.util.DBPropertyUtil;



public class CrimeDaoImpl implements CrimeDao {
	Connection connection;
	PreparedStatement pst;	

	@Override
	public List<Crime> showCrimeDao() throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from Crime";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Crime> crimeList = new ArrayList<Crime>();
		Crime crime = null;
		while(rs.next()) {
			crime = new Crime();
			crime.setCrimeId(rs.getInt("CrimeId"));
			crime.setIncidentType(rs.getString("IncidentType"));
			crime.setIncidentDate(rs.getDate("IncidentDate"));
			crime.setLocation(rs.getString("Location"));
			crime.setDescription(rs.getString("Description"));
			crime.setStatus(rs.getString("Status"));
			crimeList.add(crime);
		}
		return crimeList;
		
		
	}

	@Override
	public Crime searchByCrimeId(int crimeId) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from Crime where CrimeID = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, crimeId);
		ResultSet rs = pst.executeQuery();
		Crime crime = null;
		if(rs.next()) {
			crime = new Crime();
			crime.setCrimeId(rs.getInt("CrimeId"));
			crime.setIncidentType(rs.getString("IncidentType"));
			crime.setIncidentDate(rs.getDate("IncidentDate"));
			crime.setLocation(rs.getString("Location"));
			crime.setDescription(rs.getString("Description"));
			crime.setStatus(rs.getString("Status"));
		}
		return crime;
	}
		


	@Override
	public Crime searchByIncidentType(String IncidentType) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from Crime where IncidentType = ?";
		pst = connection.prepareStatement(cmd);
		pst.setString(1, IncidentType);
		ResultSet rs = pst.executeQuery();
		Crime crime = null;
		if(rs.next()) {
			crime = new Crime();
			crime.setCrimeId(rs.getInt("CrimeId"));
			crime.setIncidentType(rs.getString("IncidentType"));
			crime.setIncidentDate(rs.getDate("IncidentDate"));
			crime.setLocation(rs.getString("Location"));
			crime.setDescription(rs.getString("Description"));
			crime.setStatus(rs.getString("Status"));
		}
		return crime;
		
	}

	@Override
	public Crime searchByIncidentDate(Date IncidentDate) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from Crime where IncidentDate = ?";
		pst = connection.prepareStatement(cmd);
		pst.setDate(1, IncidentDate);
		ResultSet rs = pst.executeQuery();
		Crime crime = null;
		if(rs.next()) {
			crime = new Crime();
			crime.setCrimeId(rs.getInt("CrimeId"));
			crime.setIncidentType(rs.getString("IncidentType"));
			crime.setIncidentDate(rs.getDate("IncidentDate"));
			crime.setLocation(rs.getString("Location"));
			crime.setDescription(rs.getString("Description"));
			crime.setStatus(rs.getString("Status"));
		}
		return crime;
		
	}

	@Override
	public List<Crime> showOpenIncidents() throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from Crime where Status = open";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Crime> crimeList = new ArrayList<Crime>();
		Crime crime = null;
		if(rs.next()) {
			crime = new Crime();
			crime.setCrimeId(rs.getInt("CrimeId"));
			crime.setIncidentType(rs.getString("IncidentType"));
			crime.setIncidentDate(rs.getDate("IncidentDate"));
			crime.setLocation(rs.getString("Location"));
			crime.setDescription(rs.getString("Description"));
			crime.setStatus(rs.getString("Status"));
		}
		return crimeList;
	    
	}


	@Override
	
	public String addCrimeDao(Crime crime) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd="Insert into Crime(CrimeID,IncidentType,IncidentDate,Location,Description,Status) values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, crime.getCrimeId());
		pst.setString(2, crime.getIncidentType());
		pst.setDate(3, crime.getIncidentDate());    
        pst.setString(4, crime.getLocation());
        pst.setString(5, crime.getDescription());
		pst.setString(6, crime.getStatus());
		pst.executeUpdate();
		return "Crime Record Inserted...";
		
	}

}

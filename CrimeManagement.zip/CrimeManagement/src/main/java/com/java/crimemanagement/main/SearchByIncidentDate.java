package com.java.crimemanagement.main;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;

import com.java.crimemanagement.dao.CrimeDao;
import com.java.crimemanagement.dao.CrimeDaoImpl;
import com.java.crimemanagement.model.Crime;

public class SearchByIncidentDate {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Incident Date (yyyy-mm-dd): ");
        String incidentDateStr = sc.nextLine();
        sc.close(); // Close the scanner to avoid resource leak

        // Parsing the string input to java.sql.Date
        Date incidentDate;
        try {
            incidentDate = Date.valueOf(incidentDateStr);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid date format. Please enter the date in yyyy-mm-dd format.");
            return;
        }

        CrimeDao dao = new CrimeDaoImpl();
        try {
            Crime crime = dao.searchByIncidentDate(incidentDate);
            if (crime != null) {
                System.out.println(crime);
            } else {
                System.out.println("*** Crime Record Not Found ***");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}

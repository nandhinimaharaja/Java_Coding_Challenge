package com.java.crimemanagement.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.crimemanagement.dao.CrimeDao;
import com.java.crimemanagement.dao.CrimeDaoImpl;
import com.java.crimemanagement.model.Crime;

public class SearchByIncidentType {
	public static void main(String[] args) {
		String IncidentType;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Incident Type  ");
		IncidentType = sc.next();
		CrimeDao dao = new CrimeDaoImpl();
		try {
			Crime crime = dao.searchByIncidentType(IncidentType);
			if (crime !=null) {
				System.out.println(crime);
			} else {
				System.out.println("*** Crime Record Not Found ***");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	}

}

package com.java.crimemanagement.dao;

import java.sql.SQLException;

import com.java.crimemanagement.model.Victim;

public interface VictimDao {
	Victim showByCrimeId(int crimeId) throws ClassNotFoundException, SQLException;
	Victim showByVictimId(int VictimId) throws ClassNotFoundException, SQLException;
	String addVictimDao(Victim Victim) throws ClassNotFoundException, SQLException; 

}

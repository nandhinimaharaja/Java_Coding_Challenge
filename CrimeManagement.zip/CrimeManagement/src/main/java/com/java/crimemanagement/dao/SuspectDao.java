package com.java.crimemanagement.dao;

import java.sql.SQLException;

import com.java.crimemanagement.model.Suspect;

public interface SuspectDao {
	Suspect showSuspectByCrimeId(int crimeId) throws ClassNotFoundException, SQLException;
	Suspect showSuspectBySuspectId(int SuspectId) throws ClassNotFoundException, SQLException;
	String addSuspectDao(Suspect Suspect) throws ClassNotFoundException, SQLException; 
	

}

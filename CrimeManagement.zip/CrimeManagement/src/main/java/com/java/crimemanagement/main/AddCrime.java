package com.java.crimemanagement.main;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;

import com.java.crimemanagement.dao.CrimeDao;
import com.java.crimemanagement.dao.CrimeDaoImpl;
import com.java.crimemanagement.model.Crime;

public class AddCrime {
    public static void main(String[] args) {
        Crime crime = new Crime();
        Scanner sc = new Scanner(System.in);

        try {
            System.out.println("Enter Crime ID: ");
            crime.setCrimeId(sc.nextInt());
            sc.nextLine(); // Consume newline

            System.out.println("Enter Incident Type: ");
            crime.setIncidentType(sc.nextLine());

            System.out.println("Enter Incident Date (yyyy-mm-dd): ");
            String incidentDateStr = sc.nextLine();
            crime.setIncidentDate(Date.valueOf(incidentDateStr));

            System.out.println("Enter Location: ");
            crime.setLocation(sc.nextLine());

            System.out.println("Enter Description: ");
            crime.setDescription(sc.nextLine());

            System.out.println("Enter Status: ");
            crime.setStatus(sc.nextLine());
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid input. Please check the data format.");
            return;
        } finally {
            sc.close(); // Close the scanner to avoid resource leak
        }

        CrimeDao dao = new CrimeDaoImpl();
        try {
            System.out.println(dao.addCrimeDao(crime));
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}

package com.java.crimemanagement.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.crimemanagement.dao.VictimDao;
import com.java.crimemanagement.dao.VictimDaoImpl;
import com.java.crimemanagement.model.Victim;

public class ShowByVictimID {
	public static void main(String[] args) {
		int VictimID;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Victim Id  ");
		VictimID = sc.nextInt();
		VictimDao dao = new VictimDaoImpl();
		try {
			Victim victim = dao.showByVictimId(VictimID);
			if (victim !=null) {
				System.out.println(victim);
			} else {
				System.out.println("*** victim Record Not Found ***");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	}

}

package com.java.crimemanagement.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.crimemanagement.dao.VictimDao;
import com.java.crimemanagement.dao.VictimDaoImpl;
import com.java.crimemanagement.model.Victim;

public class AddVictim {
	public static void main(String[] args) {
		Victim victim = new Victim();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Victim ID ");
		victim.setVictimID(sc.nextInt());
		System.out.println("Enter Crime ID ");
		victim.setCrimeID(sc.nextInt());
		System.out.println("Enter Name");
		victim.setName(sc.next());
		System.out.println("Enter ContactInfo");
		victim.setContactInfo(sc.next());
		System.out.println("Enter Injuries  ");
		victim.setInjuries(sc.next());
		System.out.println("Enter Age ");
		victim.setAge(sc.nextInt());
		VictimDao dao = new VictimDaoImpl();
		try {
			System.out.println(dao.addVictimDao(victim));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		
		
	}

}

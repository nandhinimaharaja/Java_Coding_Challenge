package com.java.crimemanagement.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.crimemanagement.dao.VictimDao;
import com.java.crimemanagement.dao.VictimDaoImpl;
import com.java.crimemanagement.model.Victim;

public class ShowByCrimeID {
	public static void main(String[] args) {
		int crimeId;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Crime Id  ");
		crimeId = sc.nextInt();
		VictimDao dao = new VictimDaoImpl();
		try {
			Victim victim = dao.showByCrimeId(crimeId);
			if (victim !=null) {
				System.out.println(victim);
			} else {
				System.out.println("*** Crime Record Not Found ***");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	}

}

package com.java.crimemanagement.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.crimemanagement.dao.SuspectDao;
import com.java.crimemanagement.dao.SuspectDaoImpl;
import com.java.crimemanagement.model.Suspect;

public class AddSuspect {
	public static void main(String[] args) {
		Suspect suspect = new Suspect();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Suspect ID ");
		suspect.setSuspectId(sc.nextInt());
		System.out.println("Enter Crime ID ");
		suspect.setCrimeID(sc.nextInt());
		System.out.println("Enter Name");
		suspect.setName(sc.next());
		System.out.println("Enter Description");
		suspect.setDescription(sc.next());
		System.out.println("Enter CriminalHistory  ");
		suspect.setCriminalHistory(sc.next());
		System.out.println("Enter Age ");
		suspect.setAge(sc.nextInt());
		SuspectDao dao = new SuspectDaoImpl();
		try {
			System.out.println(dao.addSuspectDao(suspect));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		
		
	}


}

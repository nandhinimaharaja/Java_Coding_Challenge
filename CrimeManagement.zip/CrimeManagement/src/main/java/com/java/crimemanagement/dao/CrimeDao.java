package com.java.crimemanagement.dao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import com.java.crimemanagement.model.Crime;

public interface CrimeDao {
	List<Crime> showCrimeDao() throws ClassNotFoundException, SQLException;
	Crime searchByCrimeId(int crimeId) throws ClassNotFoundException, SQLException;
	Crime searchByIncidentType(String IncidentType) throws ClassNotFoundException, SQLException;
	Crime searchByIncidentDate(Date IncidentDate) throws ClassNotFoundException, SQLException;
	List<Crime> showOpenIncidents() throws ClassNotFoundException, SQLException;
	String addCrimeDao(Crime Crime) throws ClassNotFoundException, SQLException; 

}

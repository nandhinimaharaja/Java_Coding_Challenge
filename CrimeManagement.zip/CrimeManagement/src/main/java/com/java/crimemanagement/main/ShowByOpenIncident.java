package com.java.crimemanagement.main;

import java.sql.SQLException;
import java.util.List;

import com.java.crimemanagement.dao.CrimeDao;
import com.java.crimemanagement.dao.CrimeDaoImpl;
import com.java.crimemanagement.model.Crime;

public class ShowByOpenIncident {
	public static void main(String[] args) {
		CrimeDao dao = new CrimeDaoImpl();
		try {
			List<Crime> crimeList = dao.showCrimeDao();
			for (Crime crime : crimeList) {
				System.out.println(crime);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

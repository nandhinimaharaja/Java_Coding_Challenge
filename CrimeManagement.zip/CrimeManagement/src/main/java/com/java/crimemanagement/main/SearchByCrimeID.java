package com.java.crimemanagement.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.crimemanagement.dao.CrimeDao;
import com.java.crimemanagement.dao.CrimeDaoImpl;
import com.java.crimemanagement.model.Crime;

public class SearchByCrimeID {
	public static void main(String[] args) {
		int crimeId;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Crime Id  ");
		crimeId = sc.nextInt();
		CrimeDao dao = new CrimeDaoImpl();
		try {
			Crime crime = dao.searchByCrimeId(crimeId);
			if (crime !=null) {
				System.out.println(crime);
			} else {
				System.out.println("*** Crime Record Not Found ***");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	}

}

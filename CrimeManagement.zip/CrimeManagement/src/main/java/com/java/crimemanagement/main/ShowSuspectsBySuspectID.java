package com.java.crimemanagement.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.crimemanagement.dao.SuspectDao;
import com.java.crimemanagement.dao.SuspectDaoImpl;
import com.java.crimemanagement.model.Suspect;

public class ShowSuspectsBySuspectID {
	public static void main(String[] args) {
		int suspectId;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Suspect Id  ");
		suspectId = sc.nextInt();
		SuspectDao dao = new SuspectDaoImpl();
		try {
			Suspect suspect = dao.showSuspectBySuspectId(suspectId);
			if (suspect !=null) {
				System.out.println(suspect);
			} else {
				System.out.println("*** Suspect Record Not Found ***");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	}

}

package com.java.crimemanagement.model;

public class Suspect {
	private int suspectId;
	private int crimeID;
	private String name;
	private String description;
	private String criminalHistory;
	private int age;
	public int getSuspectId() {
		return suspectId;
	}
	public void setSuspectId(int suspectId) {
		this.suspectId = suspectId;
	}
	public int getCrimeID() {
		return crimeID;
	}
	public void setCrimeID(int crimeID) {
		this.crimeID = crimeID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCriminalHistory() {
		return criminalHistory;
	}
	public void setCriminalHistory(String criminalHistory) {
		this.criminalHistory = criminalHistory;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Suspect(int suspectId, int crimeID, String name, String description, String criminalHistory, int age) {
		super();
		this.suspectId = suspectId;
		this.crimeID = crimeID;
		this.name = name;
		this.description = description;
		this.criminalHistory = criminalHistory;
		this.age = age;
	}
	public Suspect() {
		
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Suspect [suspectId=" + suspectId + ", crimeID=" + crimeID + ", name=" + name + ", description="
				+ description + ", criminalHistory=" + criminalHistory + ", age=" + age + "]";
	}

}

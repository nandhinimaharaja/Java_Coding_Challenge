package com.java.crimemanagement.model;

public class Victim {
	private int victimID;
	private int crimeID;
	private String name;
	private String contactInfo;
	private String injuries;
	private int age;
	public int getVictimID() {
		return victimID;
	}
	public void setVictimID(int victimID) {
		this.victimID = victimID;
	}
	public int getCrimeID() {
		return crimeID;
	}
	public void setCrimeID(int crimeID) {
		this.crimeID = crimeID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactInfo() {
		return contactInfo;
	}
	public void setContactInfo(String contactInfo) {
		this.contactInfo = contactInfo;
	}
	public String getInjuries() {
		return injuries;
	}
	public void setInjuries(String injuries) {
		this.injuries = injuries;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Victim(int victimID, int crimeID, String name, String contactInfo, String injuries, int age) {
		super();
		this.victimID = victimID;
		this.crimeID = crimeID;
		this.name = name;
		this.contactInfo = contactInfo;
		this.injuries = injuries;
		this.age = age;
	}
	public Victim() {
		
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Victim [victimID=" + victimID + ", crimeID=" + crimeID + ", name=" + name + ", contactInfo="
				+ contactInfo + ", injuries=" + injuries + ", age=" + age + "]";
	}

}

package com.java.crimemanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.java.crimemanagement.model.Victim;
import com.java.crimemanagement.util.DBConnUtil;
import com.java.crimemanagement.util.DBPropertyUtil;

public class VictimDaoImpl implements VictimDao {
	Connection connection;
	PreparedStatement pst;	


	@Override
	public Victim showByCrimeId(int CrimeId) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from Victim where VictimID = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, CrimeId);
		ResultSet rs = pst.executeQuery();
		Victim victim = null;
		if(rs.next()) {
			victim = new Victim();
			victim.setVictimID(rs.getInt("VictimID"));
			victim.setCrimeID(rs.getInt("CrimeID"));
			victim.setName(rs.getString("Name"));
			victim.setContactInfo(rs.getString("ContactInfo"));
			victim.setInjuries(rs.getString("Injuries"));
			victim.setAge(rs.getInt("Age"));
		}
		return victim;
		
		
		
	}

	@Override
	public Victim showByVictimId(int VictimId) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from Victim where VictimID = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, VictimId);
		ResultSet rs = pst.executeQuery();
		Victim victim = null;
		if(rs.next()) {
			victim = new Victim();
			victim.setVictimID(rs.getInt("VictimID"));
			victim.setCrimeID(rs.getInt("CrimeID"));
			victim.setName(rs.getString("Name"));
			victim.setContactInfo(rs.getString("ContactInfo"));
			victim.setInjuries(rs.getString("Injuries"));
			victim.setAge(rs.getInt("Age"));
		}
		return victim;
		
		
	}

	@Override
	public String addVictimDao(Victim Victim) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd="Insert into Victim(VictimID,CrimeID,Name,ContactInfo,Injuries,Age) values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, Victim.getVictimID());
		pst.setInt(2, Victim.getCrimeID());
		pst.setString(3, Victim.getName());    
        pst.setString(4, Victim.getContactInfo());
        pst.setString(5, Victim.getInjuries());
		pst.setInt(6, Victim.getAge());
		pst.executeUpdate();
		return "victim Record Inserted...";
		
	}
		
	}



package com.java.crimemanagement.model;

import java.sql.Date;

public class Crime {
	private int crimeId;
	private String incidentType;
	private Date incidentDate;
	private String location;
	private String description;
	private String Status;
	public int getCrimeId() {
		return crimeId;
	}
	public void setCrimeId(int crimeId) {
		this.crimeId = crimeId;
	}
	public String getIncidentType() {
		return incidentType;
	}
	public void setIncidentType(String incidentType) {
		this.incidentType = incidentType;
	}
	public Date getIncidentDate() {
		return incidentDate;
	}
	public void setIncidentDate(Date incidentDate) {
		this.incidentDate = incidentDate;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public Crime(int crimeId, String incidentType, Date incidentDate, String location, String description,
			String status) {
		super();
		this.crimeId = crimeId;
		this.incidentType = incidentType;
		this.incidentDate = incidentDate;
		this.location = location;
		this.description = description;
		Status = status;
	}
	public Crime() {
		
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Crime [crimeId=" + crimeId + ", incidentType=" + incidentType + ", incidentDate=" + incidentDate
				+ ", location=" + location + ", description=" + description + ", Status=" + Status + "]";
	}
	
}

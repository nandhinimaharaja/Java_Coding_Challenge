package com.java.crimemanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.crimemanagement.model.Suspect;
import com.java.crimemanagement.util.DBConnUtil;
import com.java.crimemanagement.util.DBPropertyUtil;

public class SuspectDaoImpl implements SuspectDao{
	Connection connection;
	PreparedStatement pst;	


	@Override
	public Suspect showSuspectByCrimeId(int crimeId) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from Suspect where CrimeID = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, crimeId);
		ResultSet rs = pst.executeQuery();
		Suspect suspect = null;
		if(rs.next()) {
			suspect = new Suspect();
			suspect.setSuspectId(rs.getInt("SuspectID"));
			suspect.setCrimeID(rs.getInt("CrimeID"));
			suspect.setName(rs.getString("Name"));
			suspect.setDescription(rs.getString("Description"));
			suspect.setCriminalHistory(rs.getString("CriminalHistory"));
			suspect.setAge(rs.getInt("Age"));
		}
		return suspect;
		
	}

	@Override
	public Suspect showSuspectBySuspectId(int SuspectId) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from Suspect where SuspectID = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, SuspectId);
		ResultSet rs = pst.executeQuery();
		Suspect suspect = null;
		if(rs.next()) {
			suspect = new Suspect();
			suspect.setSuspectId(rs.getInt("SuspectID"));
			suspect.setCrimeID(rs.getInt("CrimeID"));
			suspect.setName(rs.getString("Name"));
			suspect.setDescription(rs.getString("Description"));
			suspect.setCriminalHistory(rs.getString("CriminalHistory"));
			suspect.setAge(rs.getInt("Age"));
		}
		return suspect;
		
		
	}

	@Override
	public String addSuspectDao(Suspect Suspect) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd="Insert into Suspect(SuspectID,CrimeID,Name,Description,CriminalHistory,Age) values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, Suspect.getSuspectId());
		pst.setInt(2, Suspect.getCrimeID());
		pst.setString(3, Suspect.getName());    
        pst.setString(4, Suspect.getDescription());
        pst.setString(5, Suspect.getCriminalHistory());
		pst.setInt(6, Suspect.getAge());
		pst.executeUpdate();
		
		return "suspect Record Inserted...";
		
	}
		
	}


